package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Aadhar;

public interface Service_declarations {
	
///// Aadhar entity
	public void insertCitizen(Aadhar a);
	public List<Aadhar> getAllCitizens();
	public List<Aadhar> getAllCitizensByAadharNum(long aadharNum);
	public List<Aadhar> getRecordByCitizenName(String name);
	public void DeleteCitizenByAadharNum(long aadharNum);
	public void UpdateCitizen(Aadhar a);
}
