package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Aadhar;
import com.example.demo.service.Service_Implementations;

@RestController
@RequestMapping("/aadhar")
public class Aadhar_Controller {
	
	private Service_Implementations simp;

	@Autowired
	public Aadhar_Controller(Service_Implementations simp) {
		this.simp = simp;
	}
	
	@GetMapping("list")
	public List<Aadhar> getAllCitizens(){
		return simp.getAllCitizens();
	}
	
	
	@GetMapping("list2/{aadharNum}")
	public List<Aadhar> getCitizensByAadharNum(@PathVariable("aadharNum") long aadharNum){
		return simp.getAllCitizensByAadharNum(aadharNum);
	}
	
	@GetMapping("list3/{name}")
	public List<Aadhar> getCitizenByName(@PathVariable("name") String name){
		return simp.getRecordByCitizenName(name);
	}
	
	@PostMapping("addCitizen")
	public void addCitizen(@RequestBody Aadhar a) {
		simp.insertCitizen(a);
	}
	
	@DeleteMapping("list/{aadharNum}")
	public void deleteCitizen(@PathVariable("aadharNum") long aadharNum) {
		simp.DeleteCitizenByAadharNum(aadharNum);
	}
	
	@PutMapping("list1")
	public void updateCitizenDetails(@RequestBody Aadhar a) {
		simp.UpdateCitizen(a);
	}

}
