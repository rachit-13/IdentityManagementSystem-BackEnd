package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity   //regarding entity details
@Table(name="Aadhar") //table name
public class Aadhar {
	@Id                 //tells regarding pk
	@GeneratedValue(strategy = GenerationType.IDENTITY) //auto_increment
	
	@Column(name="AadharNumber")   //tells regarding column name
	private long aadharNum;
	
	@Column(name="name")
	private String name;
	
	@Column(name="dob")
	private String dob;
	
	@Column(name="Gender")
	private String gender;
	
	@Column(name="fatherName")
	private String fatherName;
	
	@Column(name="address")
	private String address;
	
	@Column(name="MobileNumber")   
	private long mobileNo;
	
//	private Pan pan;
	private static long generateAadharNum = 100110011001L;

	public Aadhar() {

	}

	public Aadhar(long aadharNum, String name, String dob, String gender, String fatherName, String address,
			long mobileNo) {
		this.aadharNum = generateAadharNum;
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		this.fatherName = fatherName;
		this.address = address;
		this.mobileNo = mobileNo;
		generateAadharNum++;
	}

	public long getAadharNum() {
		return aadharNum;
	}

	public void setAadharNum(long aadharNum) {
		this.aadharNum = aadharNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	
//	public Pan getPan() {
//		return pan;
//	}
//
//	public void setPan(Pan pan) {
//		this.pan = pan;
//	}

	@Override
	public String toString() {
		return "Aadhar [aadharNum=" + aadharNum + ", name=" + name + ", dob=" + dob + ", gender=" + gender
				+ ", fatherName=" + fatherName + ", address=" + address + ", mobileNo=" + mobileNo + "]";
	}	
}
