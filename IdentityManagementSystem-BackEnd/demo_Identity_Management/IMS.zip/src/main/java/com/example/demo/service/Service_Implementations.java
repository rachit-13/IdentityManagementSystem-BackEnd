package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Aadhar;
import com.example.demo.persistance.AadharRepository;

@Service
public class Service_Implementations implements Service_declarations {
	
	private AadharRepository ajpa;
	
	
	
	@Autowired
	public Service_Implementations(AadharRepository ajpa) {
		
		this.ajpa = ajpa;
	}

	@Override
	@Transactional
	public void insertCitizen(Aadhar a) {
		a.setAadharNum(0);
		ajpa.save(a);
		
	}

	@Override
	@Transactional
	public List<Aadhar> getAllCitizens() {
		List<Aadhar> list = ajpa.findAll();
		return list;
	}

	@Override
	@Transactional
	public List<Aadhar> getAllCitizensByAadharNum(long aadharNum) {
		List<Aadhar> allCitizens = ajpa.findCitizenByaadharNum(aadharNum);
		return allCitizens;
	}

	@Override
	@Transactional
	public List<Aadhar> getRecordByCitizenName(String name) {
		List<Aadhar> list = ajpa.searchCitizenByName(name);
		return list;
	}

	@Override
	@Transactional
	public void DeleteCitizenByAadharNum(long aadharNum) {
		ajpa.deleteById(aadharNum);
		
	}

	@Override
	@Transactional
	public void UpdateCitizen(Aadhar a) {
		ajpa.save(a);		
	}

}
